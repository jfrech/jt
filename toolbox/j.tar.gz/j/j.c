#include <stdio.h>

int main() {
    puts("\33[38;5;29mj\33[0m"); }
