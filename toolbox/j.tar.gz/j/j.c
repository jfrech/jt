/* Jonathan Frech, 29th and 30th of May 2020 */

#include <stdio.h>

int main() {
    puts("\33[38;5;29mj\33[0m"); }
